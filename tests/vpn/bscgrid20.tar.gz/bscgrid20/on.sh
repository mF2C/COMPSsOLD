openvpn --config /etc/openvpn/bscgrid20/bscgrid2XVPN.conf --script-security 3 --askpass /etc/openvpn/bscgrid20/pass &

